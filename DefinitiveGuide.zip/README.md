# DefinitiveGuide
Definitive Guide to HPCC
This directory contains ECL code files for The Definitive Guide to HPCC
